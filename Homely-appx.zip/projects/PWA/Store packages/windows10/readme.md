PWA Builder Generated AppX
==========================

Thanks for generating your AppX with [PWA Builder](https://www.pwabuilder.com).

If you run the `test_install.ps1` PowerShell script on your machine, you'll be able to test your app before submitting it to the store.

Testing
-------

TODO...

Submitting to the Store
-----------------------

Visit the [Dev Center](https://developer.microsoft.com) to submit your app.

TODO...
